"use client"

import type React from "react"
import { useEffect, useRef } from "react"
import { useDashboard } from "@/lib/dashboardContext"

interface SpeedometerProps {
  maxSpeed?: number
  type: "speed" | "rpm"
  size?: number
}

const Speedometer: React.FC<SpeedometerProps> = ({ maxSpeed = 200, type, size = 260 }) => {
  const { motorcycleData } = useDashboard()
  const canvasRef = useRef<HTMLCanvasElement>(null)

  // Determinar o valor e configurações com base no tipo de velocímetro
  const getValue = () => {
    if (type === "rpm") {
      return Math.round(motorcycleData.rpm / 100) / 10
    } else {
      return Math.round(motorcycleData.speed)
    }
  }

  const getUnit = () => {
    if (type === "rpm") {
      return "x1000r/min"
    } else {
      return "km/h"
    }
  }

  const getMaxValue = () => {
    if (type === "rpm") {
      return 10 // 10000 RPM max
    } else {
      return maxSpeed
    }
  }

  const getValue100Percent = () => {
    if (type === "rpm") {
      return motorcycleData.rpm / 10000
    } else {
      return motorcycleData.speed / maxSpeed
    }
  }

  const getValueDisplay = () => {
    if (type === "rpm") {
      return getValue()
    } else {
      return getValue().toString()
    }
  }

  const getTickInterval = () => {
    if (type === "rpm") {
      return 2 // de 2 em 2k
    } else {
      return 40 // de 40 em 40 km/h
    }
  }

  const getColor = () => {
    if (type === "rpm") {
      return {
        primary: "#EF4444", // red-500
        secondary: "#F59E0B", // amber-500
        tertiary: "#EF4444", // red-500
      }
    } else {
      return {
        primary: "#2563EB", // blue-600
        secondary: "#2563EB", // blue-600
        tertiary: "#F59E0B", // amber-500
      }
    }
  }

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Use the size prop for canvas dimensions
    canvas.width = size
    canvas.height = size

    const centerX = size / 2
    const centerY = size / 2
    const radius = size / 2 - 10

    const colors = getColor()
    const maxVal = getMaxValue()
    const valueRatio = getValue100Percent()

    const startAngle = Math.PI * 0.7 // Slightly flattened (126°)
    const endAngle = Math.PI * 2.3 // ~414°

    const sweepAngle = (endAngle - startAngle) * Math.min(valueRatio, 1)

    ctx.clearRect(0, 0, size, size)

    // Background arc
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius, startAngle, endAngle)
    ctx.lineWidth = size * 0.07 // Scale line width based on size
    ctx.strokeStyle = "rgba(30, 41, 59, 0.8)"
    ctx.lineCap = "butt"
    ctx.stroke()

    // Foreground arc
    ctx.beginPath()
    ctx.arc(centerX, centerY, radius, startAngle, startAngle + sweepAngle)
    ctx.lineWidth = size * 0.07 // Scale line width based on size
    ctx.lineCap = "round"
    const gradient = ctx.createLinearGradient(0, 0, size, 0)
    gradient.addColorStop(0, colors.primary)
    gradient.addColorStop(0.7, colors.secondary)
    gradient.addColorStop(1, colors.tertiary)
    ctx.strokeStyle = gradient
    ctx.stroke()

    // Ticks and labels
    const interval = getTickInterval()
    for (let i = 0; i <= maxVal; i += interval) {
      const angle = startAngle + (i / maxVal) * (endAngle - startAngle)
      const innerRadius = radius - size * 0.04 // Scale based on size
      const outerRadius = radius + size * 0.01 // Scale based on size

      const startX = centerX + innerRadius * Math.cos(angle)
      const startY = centerY + innerRadius * Math.sin(angle)
      const endX = centerX + outerRadius * Math.cos(angle)
      const endY = centerY + outerRadius * Math.sin(angle)

      ctx.beginPath()
      ctx.moveTo(startX, startY)
      ctx.lineTo(endX, endY)
      ctx.lineWidth = size * 0.008 // Scale line width based on size
      ctx.strokeStyle = "#FFFFFF"
      ctx.stroke()

      // Labels - only show if size is large enough
      if (i > 0 && i < maxVal && size > 150) {
        const labelRadius = radius - size * 0.11 // Scale based on size
        const labelX = centerX + labelRadius * Math.cos(angle)
        const labelY = centerY + labelRadius * Math.sin(angle)

        ctx.fillStyle = "#FFFFFF"
        ctx.font = `${size * 0.046}px Roboto Mono, monospace` // Scale font based on size
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText(i.toString(), labelX, labelY)
      }
    }
  }, [motorcycleData, type, size])

  return (
    <div className="speedometer relative flex justify-center items-center h-full">
      <canvas ref={canvasRef} className="w-full h-full" style={{ maxWidth: "100%", maxHeight: "100%" }} />
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
        <div className="speed-unit font-medium text-xs text-gray-300 mb-0">{getUnit()}</div>
        <div
          className={`speed-value font-mono font-bold text-[${size * 0.09}px] leading-tight ${type === "rpm" ? "text-red-400" : "text-blue-400"}`}
        >
          {getValueDisplay()}
        </div>
      </div>
    </div>
  )
}

export default Speedometer
