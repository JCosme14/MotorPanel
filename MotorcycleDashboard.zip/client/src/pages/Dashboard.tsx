"use client"

import type React from "react"
import { useEffect, useState } from "react"
import StatusBar from "@/components/StatusBar"
import Speedometer from "@/components/Speedometer"
import GearIndicator from "@/components/GearIndicator"
import BatteryIndicator from "@/components/BatteryIndicator"
import WarningPanel from "@/components/WarningPanel"
import QuickActions from "@/components/QuickActions"
import { useDashboard } from "@/lib/dashboardContext"
import { Responsive, WidthProvider } from "react-grid-layout"
import "react-grid-layout/css/styles.css"
import "react-resizable/css/styles.css"
import { Button } from "@/components/ui/button"
import { Save, Grid, Lock, RotateCcw } from "lucide-react"

// Create a responsive grid layout
const ResponsiveGridLayout = WidthProvider(Responsive)

// Define component types for the dashboard
type DashboardComponent = {
  id: string
  name: string
  component: React.ReactNode
  defaultLayout: {
    x: number
    y: number
    w: number
    h: number
    minW?: number
    minH?: number
  }
  className?: string
}

const Dashboard: React.FC = () => {
  const { motorcycleData, userSettings, isDarkMode, loading, error, saveDashboardLayout } = useDashboard()

  // State for edit mode
  const [isEditMode, setIsEditMode] = useState(false)

  // State for layouts
  const [layouts, setLayouts] = useState(() => {
    // Try to load saved layouts from localStorage
    const savedLayouts = localStorage.getItem("dashboardLayouts")
    return savedLayouts ? JSON.parse(savedLayouts) : null
  })

  // Define dashboard components with their default layouts
  const dashboardComponents: DashboardComponent[] = [
    {
      id: "status",
      name: "Status Bar",
      component: <StatusBar />,
      defaultLayout: { x: 0, y: 0, w: 12, h: 1, minW: 3, minH: 1 },
    },
    {
      id: "battery",
      name: "Battery",
      component: <BatteryIndicator />,
      defaultLayout: { x: 0, y: 1, w: 12, h: 2, minW: 3, minH: 2 },
    },
    {
      id: "speedometer",
      name: "Speed",
      component: <Speedometer maxSpeed={200} type="speed" />,
      defaultLayout: { x: 0, y: 3, w: 4, h: 8, minW: 3, minH: 6 },
      className: "flex items-center justify-center",
    },
    {
      id: "rpm",
      name: "RPM",
      component: <Speedometer maxSpeed={200} type="rpm" />,
      defaultLayout: { x: 7, y: 3, w: 4, h: 8, minW: 3, minH: 6 },
      className: "flex items-center justify-center",
    },
    {
      id: "gear",
      name: "Gear",
      component: <GearIndicator />,
      defaultLayout: { x: 4, y: 6, w: 2, h: 3, minW: 2, minH: 3 },
    },
    {
      id: "warnings",
      name: "Warnings",
      component: <WarningPanel />,
      defaultLayout: { x: 0, y: 11, w: 12, h: 2, minW: 3, minH: 2 },
    },
    {
      id: "actions",
      name: "Actions",
      component: <QuickActions />,
      defaultLayout: { x: 0, y: 13, w: 12, h: 2, minW: 3, minH: 1 },
    },
  ]

  // Generate layout from components if no saved layout exists
  const generateDefaultLayout = () => {
    return {
      lg: dashboardComponents.map((item) => ({
        i: item.id,
        ...item.defaultLayout,
        static: !isEditMode,
      })),
      md: dashboardComponents.map((item) => ({
        i: item.id,
        ...item.defaultLayout,
        w: Math.min(item.defaultLayout.w, 10), // Adjust width for medium screens
        static: !isEditMode,
      })),
      sm: dashboardComponents.map((item) => ({
        i: item.id,
        x: 0,
        y: item.defaultLayout.y,
        w: 6,
        h: item.defaultLayout.h,
        static: !isEditMode,
      })),
    }
  }

  // Get current layout
  const currentLayouts = layouts || generateDefaultLayout()

  // Update layout static property based on edit mode
  const getLayoutsWithStaticProp = () => {
    const updatedLayouts = { ...currentLayouts }

    Object.keys(updatedLayouts).forEach((breakpoint) => {
      updatedLayouts[breakpoint] = updatedLayouts[breakpoint].map((item) => ({
        ...item,
        static: !isEditMode,
        isDraggable: isEditMode,
      }))
    })

    return updatedLayouts
  }

  // Handle layout change
  const handleLayoutChange = (currentLayout: any, allLayouts: any) => {
    // Only update layouts when in edit mode to prevent unintended changes
    if (isEditMode) {
      setLayouts(allLayouts)
      // Save to localStorage immediately to ensure we don't lose changes
      localStorage.setItem("dashboardLayouts", JSON.stringify(allLayouts))
    }
  }

  // Save layout to localStorage and via context
  const saveLayout = async () => {
    try {
      // First save to localStorage as a backup
      localStorage.setItem("dashboardLayouts", JSON.stringify(layouts))

      // Then try to save via the context
      if (saveDashboardLayout) {
        await saveDashboardLayout(layouts)
      }

      // Show success feedback
      console.log("Layout saved successfully")

      // Exit edit mode
      setIsEditMode(false)
    } catch (error) {
      console.error("Error saving layout:", error)
      // Still save to localStorage even if API fails
      localStorage.setItem("dashboardLayouts", JSON.stringify(layouts))
      setIsEditMode(false)
    }
  }

  // Reset layout to default
  const resetLayout = () => {
    localStorage.removeItem("dashboardLayouts")
    setLayouts(null)
    setIsEditMode(false)
  }

  // Toggle edit mode
  const toggleEditMode = () => {
    setIsEditMode(!isEditMode)
  }

  useEffect(() => {
    // Import Material Icons
    const link = document.createElement("link")
    link.href = "https://fonts.googleapis.com/icon?family=Material+Icons"
    link.rel = "stylesheet"
    document.head.appendChild(link)

    // Import fonts
    const fontLink = document.createElement("link")
    fontLink.href =
      "https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&family=Roboto+Mono:wght@500;700&display=swap"
    fontLink.rel = "stylesheet"
    document.head.appendChild(fontLink)

    return () => {
      document.head.removeChild(link)
      document.head.removeChild(fontLink)
    }
  }, [])

  // Apply dark mode class to body
  useEffect(() => {
    if (isDarkMode) {
      document.body.classList.add("dark")
    } else {
      document.body.classList.remove("dark")
    }
  }, [isDarkMode])

  // Add this CSS at the top of the component to ensure components remain visible during drag
  useEffect(() => {
    // Add CSS to make dragged items visible
    const style = document.createElement("style")
    style.innerHTML = `
    .react-grid-item.react-draggable-dragging {
      z-index: 100;
      opacity: 0.8;
      transition: none !important;
    }
    .edit-component {
      box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.5);
    }
    .drag-handle {
      cursor: move;
    }
    .speedometer {
      display: flex !important;
      justify-content: center !important;
      align-items: center !important;
      height: 100% !important;
    }
    .speedometer canvas {
      max-width: 100%;
      max-height: 100%;
      width: auto !important;
      height: auto !important;
    }
    .react-grid-layout {
      background-color: #111827; /* Match bg-gray-900 */
    }
    .dashboard-item {
      border: 1px solid rgba(75, 85, 99, 0.5);
      background-color: #1f2937 !important;
      border-radius: 0.375rem;
      overflow: hidden;
      box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
    }
    .dashboard-item > div {
      background-color: #171d2a !important;
    }
    /* Override any component-specific backgrounds */
    .dashboard-item .bg-gray-900,
    .dashboard-item .bg-black,
    .dashboard-item .bg-gray-800,
    .dashboard-item [class*="bg-gray-"] {
      background-color: #171d2a !important;
    }
    /* Ensure content area has the right background */
    .dashboard-item-content {
      background-color: #171d2a !important;
      height: 100%;
    }
  `
    document.head.appendChild(style)

    return () => {
      document.head.removeChild(style)
    }
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900">
        <div className="text-primary font-medium">Loading dashboard...</div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900">
        <div className="text-destructive font-medium">{error}</div>
      </div>
    )
  }

  return (
    <div id="dashboard" className="font-sans bg-gray-900 text-white min-h-screen touch-manipulation">
      <div className="max-w-5xl mx-auto h-full p-2">
        {/* Edit Mode Controls */}
        <div className="flex justify-end mb-2 gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={toggleEditMode}
            className={`${isEditMode ? "bg-blue-500 text-white" : "bg-gray-800"}`}
          >
            {isEditMode ? <Lock className="mr-1 h-4 w-4" /> : <Grid className="mr-1 h-4 w-4" />}
            {isEditMode ? "Sair Modo Edição" : "Editar"}
          </Button>

          {isEditMode && (
            <>
              <Button variant="outline" size="sm" onClick={saveLayout} className="bg-green-600 text-white">
                <Save className="mr-1 h-4 w-4" />
                Salvar Layout
              </Button>

              <Button variant="outline" size="sm" onClick={resetLayout} className="bg-red-600 text-white">
                <RotateCcw className="mr-1 h-4 w-4" />
                Reverter
              </Button>
            </>
          )}
        </div>

        {/* Grid Layout */}
        <div className={`h-[calc(100vh-80px)] ${isEditMode ? "edit-mode" : ""} bg-gray-900`}>
          <ResponsiveGridLayout
            className="layout"
            layouts={getLayoutsWithStaticProp()}
            breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }}
            cols={{ lg: 12, md: 10, sm: 6, xs: 4, xxs: 2 }}
            rowHeight={40}
            margin={[8, 8]}
            containerPadding={[0, 0]}
            onLayoutChange={handleLayoutChange}
            isDraggable={isEditMode}
            isResizable={isEditMode} // Allow resizing in edit mode
            compactType={null} // Disable automatic compacting
            preventCollision={true} // Prevent components from overlapping
            useCSSTransforms={true}
            draggableHandle=".drag-handle" // Only drag from the handle
          >
            {dashboardComponents.map((item) => (
              <div
                key={item.id}
                className={`dashboard-item ${isEditMode ? "edit-component border-2 border-blue-500" : ""}`}
              >
                {isEditMode && (
                  <div className="bg-blue-500 text-white text-xs p-1 drag-handle flex items-center justify-between cursor-move">
                    <div>
                      <span className="material-icons text-sm mr-1">drag_indicator</span>
                      {item.name}
                    </div>
                    <div className="text-xs opacity-75">Drag to move</div>
                  </div>
                )}
                <div className={`dashboard-item-content ${item.className || ""}`}>{item.component}</div>
              </div>
            ))}
          </ResponsiveGridLayout>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
