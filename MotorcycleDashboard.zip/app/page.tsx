"use client"

import BatteryIndicator from "../client/src/components/BatteryIndicator"

export default function SyntheticV0PageForDeployment() {
  return <BatteryIndicator />
}
